# RESEARCH_SOURCES.md

Status: IN PROGRESS (Part 9 slice only; Parts 1 to 8 have no research logged yet)
Purpose: Registry of every source used, with reliability and what it supports.

Types: `OFFICIAL-ROBLOX` (Creator Hub docs), `OFFICIAL-ANNOUNCEMENT` (Roblox staff DevForum posts), `COMMUNITY`, `SECONDARY-MIRROR`, `PRIMARY-MEDIA`, `GAME-OBSERVED`, `WIKI-SECONDARY`.
Rules: community/wiki sources are `REPORTED`; never cite a source you have not opened; note when only a search snippet was seen.

## Source log
| ID | Source | Type | URL | Accessed | Access depth | Supports |
|---|---|---|---|---|---|---|
| R01 | Securing the client-server boundary (page last_updated 2026-11-20) | OFFICIAL-ROBLOX | https://create.roblox.com/docs/scripting/security/client-server-boundary | 2026-11-22 | full page | Remote validation, NaN, rate limiting, weapon targeting, gatekeeper pattern |
| R02 | Security and cheat mitigation tactics (2026-10-20) | OFFICIAL-ROBLOX | https://create.roblox.com/docs/scripting/security/security-tactics | 2026-11-22 | search excerpts | Server as source of truth; client untrusted; device trust note |
| R03 | Server-side detection and consequencing | OFFICIAL-ROBLOX | https://create.roblox.com/docs/en-us/scripting/security/server-side-detection | 2026-11-22 | search excerpts | Heuristics, honeypots, detection principles |
| R04 | Network ownership, movement validation, and physics (2026-07-10) | OFFICIAL-ROBLOX | https://create.roblox.com/docs/scripting/security/network-ownership | 2026-11-22 | search excerpts (partly localized text) | Ownership security, movement validation, Server Authority mention |
| R05 | WorldRoot class reference (2026-11-20) | OFFICIAL-ROBLOX | https://create.roblox.com/docs/en-us/reference/engine/classes/WorldRoot.md | 2026-11-22 | full page | Spatial queries, casts, deprecations, limits |
| R06 | OverlapParams (2026-11-06) | OFFICIAL-ROBLOX | https://create.roblox.com/docs/reference/engine/datatypes/OverlapParams.md | 2026-11-22 | full page | Include/ExcludeInstances supersede FilterDescendantsInstances |
| R07 | Animation events (2026-10-16) | OFFICIAL-ROBLOX | https://create.roblox.com/docs/en-us/animation/events | 2026-11-22 | search excerpts | Event markers, GetMarkerReachedSignal |
| R08 | UnreliableRemoteEvent reference | OFFICIAL-ROBLOX | https://create.roblox.com/docs/reference/engine/classes/UnreliableRemoteEvent | 2026-11-22 | search excerpt | 900-byte limit, unordered/unreliable semantics |
| R09 | robloxapi.github.io UnreliableRemoteEvent reference | SECONDARY-MIRROR | https://robloxapi.github.io/ref/class/UnreliableRemoteEvent.html | 2026-11-22 | search excerpt | ~500 req/s per client claim (UNVERIFIED) |
| R10 | Server authority model | OFFICIAL-ROBLOX | https://create.roblox.com/docs/projects/server-authority | 2026-11-22 | search excerpts | Prediction/rollback model, setup, limitations |
| R11 | Server Authority DevForum announcements (Studio Beta; Studio Beta Updates; Client Beta) | OFFICIAL-ANNOUNCEMENT | https://devforum.roblox.com/t/client-beta-publish-test-your-server-authoritative-experiences/4606949 and related | 2026-11-22 | search excerpts | Beta stage, animation limit (early access), Team Test notes (may be outdated) |
| R12 | Introducing OverlapParams (DevForum) | COMMUNITY/ANNOUNCEMENT | https://devforum.roblox.com/t/introducing-overlapparams-new-spatial-query-api/1435720 | 2026-11-22 | search excerpts | Historical context; anecdotal performance posts (REPORTED) |
| R13 | "Incorrect size of data being sent limit... UnreliableRemoteEvent" (DevForum bug-report thread) | COMMUNITY | https://devforum.roblox.com/t/incorrect-size-of-data-being-sent-limit-specified-when-using-unreliableremoteevent/3048788 | 2026-11-22 | search excerpt | Buffers compressed before the 900-byte limit applies (REPORTED) |

## Research queue
| Part | Topic | Preferred sources |
|---|---|---|
| 1 | Jujutsu Infinite, Jujutsu: RETRO, Sorcery, Shibuya, other Roblox JJK games | Game pages, developer notes/updates, wikis (REPORTED) |
| 1 | Action RPG and fighting-game references | Developer talks, official documentation |
| 2 | JJK lore | Manga/anime primary; wikis only as secondary |
| 3 to 6 | Combat, injury, animation, VFX/SFX | Roblox Creator Hub, developer talks |
| 9 | Remaining Roblox APIs (see handbook README "Not yet researched") | create.roblox.com/docs |
