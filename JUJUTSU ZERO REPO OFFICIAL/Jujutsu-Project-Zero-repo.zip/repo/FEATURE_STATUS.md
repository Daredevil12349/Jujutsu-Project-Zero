# FEATURE_STATUS.md

Status: LIVE TRACKER (update every session)
Last updated: 2026-11-22 (session 2)

Legend: [x] done, [~] in progress, [ ] not started

## A. Repository build checklist
### Core files
- [x] README.md
- [x] CLAUDE.md
- [x] PROJECT_RULES.md
- [x] MASTER_GAME_DESIGN.md (draft, from owner vision; no external research)
- [x] TECHNICAL_ARCHITECTURE.md (draft)
- [x] DEVELOPMENT_ROADMAP.md
- [x] FEATURE_STATUS.md
- [x] RESEARCH_SOURCES.md (framework + research queue; no sources logged yet)
- [x] ASSET_LICENSING.md
### Templates
- [x] technique, animation, vfx, sfx, boss, system, lore, research-entry
### Directory indexes (README per docs folder)
- [x] docs/01 to docs/09 index files (all STUB)
### Content phases (each needs its own session)
- [ ] Part 1: reference-game research (Jujutsu Infinite, RETRO, Sorcery, Shibuya, others, action RPG / fighting-game references)
- [ ] Part 2: JJK encyclopedia
- [ ] Part 3: combat engineering docs
- [ ] Part 4: damage, slashing, RCT
- [ ] Part 5: animation database
- [ ] Part 6: VFX/SFX library
- [ ] Part 7: technique database
- [ ] Part 8: progression and probability tables
- [~] Part 9: Roblox technical handbook (5 files done: validation, hit detection, remotes, server authority, animation events; remaining topics listed in docs/09-roblox-handbook/README.md)
- [ ] Final audit report

## B. Game systems
- [ ] PlayerData (DataStore + session lock)
- [ ] CharacterInit
- [ ] Stats
- [ ] Input
- [ ] Camera (over-the-shoulder)
- [ ] Movement (sprint, dash)
- [ ] Combat state machine
- [ ] M1 combo (4-hit)
- [ ] Block / perfect block / parry / dodge
- [ ] Hit reactions and knockdowns
- [ ] Cursed energy and reinforcement
- [ ] First technique
- [ ] Injury visuals (stylized)
- [ ] RCT (basic regeneration)
- [ ] Test arena + dummy

## Known contradictions
None logged.
